/* =========================================================
   firebase-config.js
   - عبّئي هذا الملف ببيانات مشروع Firebase الخاص بك حتى تصبح
     بيانات تجهيزات العرس محفوظة ومتزامنة بين كل من يفتح موقعك
     (على أي جهاز، بدون تسجيل دخول).
   - إذا تركتِه بلا تعبئة (FIREBASE_CONFIG = null) سيستمر
     الموقع بالعمل تمامًا، لكن البيانات تُحفظ على كل جهاز لوحده
     فقط (LocalStorage) بدون مزامنة بين الأجهزة.
   - خطوات الحصول على القيم موثقة في README.md تحت عنوان
     "الربط بـ Firebase".
   ========================================================= */

const FIREBASE_CONFIG = null;

/* مثال (استبدلي القيم بالقيم الحقيقية من Firebase Console):
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "your-project-id.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890abcdef"
};
*/
